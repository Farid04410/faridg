import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-charcoal text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-left">
          <div className="space-y-4 md:col-span-2">
            <Link to="/">
              <span className="text-2xl font-bold text-white">
                Farid Khan
              </span>
            </Link>
            <p className="text-gray-400 text-sm max-w-md mx-auto md:mx-0">
              Expert in Sales, Marketing & Business Development, helping you grow your business.
            </p>
          </div>

          <div>
            <p className="font-bold text-white mb-4">Quick Links</p>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Me</Link></li>
              <li><Link to="/services" className="text-gray-400 hover:text-white transition-colors">Services</Link></li>
              <li><Link to="/portfolio" className="text-gray-400 hover:text-white transition-colors">Portfolio</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <p className="font-bold text-white mb-4">Follow Me</p>
            <div className="flex space-x-4 justify-center md:justify-start">
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Facebook /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Twitter /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Linkedin /></a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors"><Instagram /></a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Farid Khan. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;