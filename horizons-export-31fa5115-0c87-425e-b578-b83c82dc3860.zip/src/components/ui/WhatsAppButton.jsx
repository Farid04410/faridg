import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare } from 'lucide-react'; // Using MessageSquare for a generic chat icon

const WhatsAppButton = ({ phoneNumber }) => {
  const url = `https://wa.me/${phoneNumber}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
    >
      <motion.div
        className="fixed bottom-6 right-6 w-16 h-16 bg-green-500 rounded-full flex items-center justify-center shadow-lg cursor-pointer z-50"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <MessageSquare className="w-8 h-8 text-white" />
      </motion.div>
    </a>
  );
};

export default WhatsAppButton;