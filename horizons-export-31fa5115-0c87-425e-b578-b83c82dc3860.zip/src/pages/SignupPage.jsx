import React from "react";
const SignupPage = () => {
  return null;
};
export default SignupPage;