import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ResumePage = () => {
    const { toast } = useToast();

    const handleDownload = () => {
        toast({
          title: "🚧 Download Not Available",
          description: "The downloadable PDF will be added soon!",
        });
    };

  return (
    <>
      <Helmet>
        <title>Resume - Farid Khan</title>
        <meta name="description" content="View the detailed resume and CV of Farid Khan, sales and marketing expert." />
      </Helmet>
      <section className="section bg-white">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">My Resume</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              A summary of my professional experience, skills, and education.
            </p>
            <Button onClick={handleDownload} size="lg" className="btn-primary mt-8">
              Download PDF <Download className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>

          <div className="mt-16 max-w-4xl mx-auto">
            {/* Experience Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <h2 className="text-2xl font-bold border-b-2 border-royal-blue pb-2 mb-6">Experience</h2>
              <div className="space-y-6">
                <div className="card !p-6">
                  <h3 className="text-xl font-bold">Senior Sales Manager</h3>
                  <p className="text-gray-500">ABC Corporation | 2020 - Present</p>
                  <ul className="list-disc list-inside mt-2 text-gray-600">
                    <li>Increased team sales by 40% in the first year.</li>
                    <li>Developed and implemented a new CRM strategy.</li>
                    <li>Mentored a team of 10 sales representatives.</li>
                  </ul>
                </div>
                <div className="card !p-6">
                  <h3 className="text-xl font-bold">Marketing Specialist</h3>
                  <p className="text-gray-500">XYZ Solutions | 2017 - 2020</p>
                  <ul className="list-disc list-inside mt-2 text-gray-600">
                    <li>Managed digital marketing campaigns with a budget of $500k.</li>
                    <li>Grew social media following by 150%.</li>
                  </ul>
                </div>
              </div>
            </motion.div>

            {/* Skills Section */}
            <motion.div
              className="mt-12"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <h2 className="text-2xl font-bold border-b-2 border-royal-blue pb-2 mb-6">Skills</h2>
              <div className="flex flex-wrap gap-2">
                {['Sales Strategy', 'Business Development', 'CRM', 'Digital Marketing', 'Lead Generation', 'Team Leadership'].map(skill => (
                  <span key={skill} className="bg-blue-100 text-royal-blue font-semibold px-4 py-2 rounded-full">{skill}</span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ResumePage;