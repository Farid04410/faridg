import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  { question: 'What industries do you specialize in?', answer: 'I have experience across a wide range of industries, including tech, SaaS, e-commerce, and professional services. My strategies are adaptable to any business model.' },
  { question: 'How do you measure the success of a project?', answer: 'Success is measured against pre-defined Key Performance Indicators (KPIs) that we establish together at the start of the project. This could include metrics like revenue growth, lead conversion rates, or market share.' },
  { question: 'What is your process for starting a new project?', answer: 'It starts with a discovery call to understand your business, goals, and challenges. From there, I develop a tailored proposal. Once agreed, we kick off with a detailed strategy session.' },
  { question: 'Do you work with startups and small businesses?', answer: 'Absolutely! I am passionate about helping businesses of all sizes grow. I offer flexible consulting packages to suit the needs and budgets of startups and small businesses.' },
];

const FaqItem = ({ faq }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left py-6"
      >
        <span className="text-lg font-semibold text-charcoal-black">{faq.question}</span>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
          <ChevronDown className="w-6 h-6 text-royal-blue" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <p className="pb-6 text-gray-600">{faq.answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const FaqPage = () => {
  return (
    <>
      <Helmet>
        <title>FAQ - Farid Khan</title>
        <meta name="description" content="Find answers to common questions about Farid Khan's services and expertise." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">Frequently Asked Questions</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              Here are answers to some of the most common questions I receive.
            </p>
          </motion.div>

          <div className="mt-16 max-w-3xl mx-auto">
            {faqs.map((faq, index) => (
              <FaqItem key={index} faq={faq} />
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default FaqPage;