import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';

const testimonials = [
  { name: 'John Doe', company: 'CEO, Alpha Corp', text: 'Farid\'s strategic insights were a game-changer for our sales team. He is professional, dedicated, and delivers results.', avatar: 'A portrait of a smiling CEO.' },
  { name: 'Jane Smith', company: 'Marketing Director, Beta Inc', text: 'Working with Farid was a pleasure. His marketing campaigns are creative and, most importantly, effective. Highly recommended!', avatar: 'A professional woman in a modern office.' },
  { name: 'Samuel Green', company: 'Founder, Gamma LLC', text: 'Farid helped us build our business from the ground up. His guidance in business development was invaluable to our success.', avatar: 'A confident startup founder.' },
];

const TestimonialsPage = () => {
  return (
    <>
      <Helmet>
        <title>Testimonials - Farid Khan</title>
        <meta name="description" content="See what clients and employers are saying about Farid Khan's work and expertise." />
      </Helmet>
      <section className="section bg-white">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">What My Clients Say</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              I'm proud to have earned the trust of my clients. Here's what they have to say about working with me.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.name}
                className="card text-left"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="flex text-yellow-400 mb-4">
                  {[...Array(5)].map((_, i) => <Star key={i} fill="currentColor" size={20} />)}
                </div>
                <p className="text-gray-600 mb-6 italic">"{testimonial.text}"</p>
                <div className="flex items-center gap-4">
                  <img  className="w-14 h-14 rounded-full object-cover" alt={testimonial.name} src="https://images.unsplash.com/photo-1649399045831-40bfde3ef21d" />
                  <div>
                    <p className="font-bold text-charcoal-black">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.company}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default TestimonialsPage;