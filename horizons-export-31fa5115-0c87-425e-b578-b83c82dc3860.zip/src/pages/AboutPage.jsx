import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Award, Briefcase, Target } from 'lucide-react';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Me - Farid Khan</title>
        <meta name="description" content="Learn about Farid Khan's professional background, mission, and achievements in sales and marketing." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-center"
          >
            <h1 className="section-title">About Me</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              A passionate and results-driven professional with a knack for building connections and driving business growth.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <img  
                className="rounded-lg shadow-2xl w-full h-auto object-cover"
                alt="Professional portrait of Farid Khan"
               src="https://images.unsplash.com/photo-1613186267015-46dc938f2b8f" />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="space-y-8"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                  <Target className="w-6 h-6 text-royal-blue" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">My Mission</h3>
                  <p className="text-gray-600">My mission is to empower businesses with innovative sales and marketing strategies that not only meet but exceed their goals. I believe in building lasting partnerships based on trust, transparency, and tangible results.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                  <Briefcase className="w-6 h-6 text-royal-blue" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">My Background</h3>
                  <p className="text-gray-600">With over [X] years of experience in the industry, I have a proven track record of developing successful sales funnels, leading high-performing teams, and executing marketing campaigns that resonate with audiences.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                  <Award className="w-6 h-6 text-royal-blue" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">My Achievements</h3>
                  <p className="text-gray-600">Consistently recognized for exceeding sales targets, pioneering new market entry strategies, and mentoring upcoming talent. My focus is always on creating value and driving sustainable growth.</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default AboutPage;