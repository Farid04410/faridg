import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const blogPosts = [
  { title: 'The 5 Pillars of a Winning Sales Strategy', date: 'July 10, 2025', excerpt: 'Discover the foundational elements that can transform your sales process...', image: 'An abstract image of pillars.' },
  { title: 'Why Your Business Needs a CRM, Yesterday', date: 'June 28, 2025', excerpt: 'A deep dive into how Customer Relationship Management systems can revolutionize your business.', image: 'A computer screen showing a CRM dashboard.' },
  { title: 'Unlocking Growth: A Guide to Business Development', date: 'June 15, 2025', excerpt: 'Simple, actionable steps to identify and capitalize on new growth opportunities.', image: 'A key unlocking a door.' },
];

const BlogPage = () => {
    const { toast } = useToast();

    const handleReadMore = () => {
        toast({
          title: "🚧 Blog Post Coming Soon",
          description: "The full article will be available shortly. Stay tuned!",
        });
    };

  return (
    <>
      <Helmet>
        <title>Blog - Farid Khan</title>
        <meta name="description" content="Read insights and tips on sales, marketing trends, and business development from Farid Khan." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">My Insights</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              Sharing knowledge and trends from the world of sales, marketing, and business development.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, index) => (
              <motion.div
                key={post.title}
                className="card overflow-hidden"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <img  className="w-full h-56 object-cover" alt={post.title} src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                <div className="p-6">
                  <p className="text-sm text-gray-500 mb-1">{post.date}</p>
                  <h3 className="text-2xl font-bold text-charcoal-black mb-2 leading-tight">{post.title}</h3>
                  <p className="text-gray-600 mb-4">{post.excerpt}</p>
                  <button onClick={handleReadMore} className="font-bold text-royal-blue hover:underline flex items-center gap-2">
                    Read More <ArrowRight size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default BlogPage;