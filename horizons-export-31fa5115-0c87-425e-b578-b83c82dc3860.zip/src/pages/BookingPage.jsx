import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Calendar, Video, Phone } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const BookingPage = () => {
    const { toast } = useToast();

    const handleBooking = (type) => {
         toast({
          title: `🚧 ${type} Booking`,
          description: "This booking feature isn't implemented yet. Please use the WhatsApp button or Contact page for now!",
        });
    }

  return (
    <>
      <Helmet>
        <title>Book a Call - Farid Khan</title>
        <meta name="description" content="Schedule a consultation with Farid Khan. Book a discovery call via calendar, video, or phone." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">Book a Consultation</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              Ready to discuss your project? Choose your preferred method to schedule a free 30-minute discovery call.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <motion.div
              className="card text-center"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Calendar className="w-12 h-12 mx-auto text-royal-blue mb-4" />
              <h3 className="text-2xl font-bold mb-2">Schedule Online</h3>
              <p className="text-gray-600 mb-6">Pick a time and date that works for you using my online calendar.</p>
              <Button onClick={() => handleBooking('Online')} className="btn-primary">Book Now</Button>
            </motion.div>

            <motion.div
              className="card text-center"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Video className="w-12 h-12 mx-auto text-royal-blue mb-4" />
              <h3 className="text-2xl font-bold mb-2">Request a Video Call</h3>
              <p className="text-gray-600 mb-6">Let's connect face-to-face over Google Meet or Zoom.</p>
              <Button onClick={() => handleBooking('Video Call')} className="btn-primary">Request Call</Button>
            </motion.div>
            
            <motion.div
              className="card text-center"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <Phone className="w-12 h-12 mx-auto text-royal-blue mb-4" />
              <h3 className="text-2xl font-bold mb-2">Quick Phone Chat</h3>
              <p className="text-gray-600 mb-6">Prefer a quick chat? Send me a message, and I'll call you back.</p>
              <Button onClick={() => handleBooking('Phone Chat')} className="btn-primary">Get a Callback</Button>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default BookingPage;