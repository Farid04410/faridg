import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { TrendingUp, Briefcase, Zap, Search, PenTool, PhoneCall } from 'lucide-react';

const services = [
  { icon: TrendingUp, title: 'Sales Strategy & Execution', description: 'Developing and implementing robust sales strategies to boost your bottom line.' },
  { icon: Briefcase, title: 'Business Development Consulting', description: 'Identifying new market opportunities and forging strategic partnerships.' },
  { icon: Zap, title: 'Lead Generation & CRM Guidance', description: 'Building a consistent pipeline of quality leads and managing them efficiently.' },
  { icon: Search, title: 'Digital Marketing Basics', description: 'Helping you navigate the world of social media and online presence.' },
  { icon: PenTool, title: 'Marketing Campaign Design', description: 'Creating compelling campaigns that capture attention and drive action.' },
  { icon: PhoneCall, title: 'Cold Calling Strategy & Training', description: 'Mastering the art of effective outreach to turn prospects into clients.' },
];

const ServicesPage = () => {
  return (
    <>
      <Helmet>
        <title>Services - Farid Khan</title>
        <meta name="description" content="Explore the sales, marketing, and business development services offered by Farid Khan." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">My Services</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              A comprehensive suite of services designed to accelerate your growth and enhance your market position.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                className="card text-left"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6">
                  <service.icon className="w-8 h-8 text-royal-blue" />
                </div>
                <h3 className="text-2xl font-bold text-charcoal-black mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </motion.div>
            ))}
          </div>
          
          <motion.div 
            className="text-center mt-20"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <h2 className="text-2xl font-bold mb-4">Have a specific need?</h2>
            <p className="text-gray-600 mb-8">Let's discuss a custom solution tailored just for you.</p>
            <Link to="/contact">
              <Button size="lg" className="btn-primary">Contact Me</Button>
            </Link>
          </motion.div>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;