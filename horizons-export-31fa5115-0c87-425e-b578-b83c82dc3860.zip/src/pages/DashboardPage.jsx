import React from "react";
const DashboardPage = () => {
  return null;
};
export default DashboardPage;