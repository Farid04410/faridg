import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { ExternalLink } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const portfolioItems = [
  {
    title: 'Project Alpha',
    category: 'Sales Strategy',
    description: 'Developed a new sales channel that increased revenue by 30% in six months.',
    image: 'A chart with an upward trending graph.',
  },
  {
    title: 'Campaign Beta',
    category: 'Digital Marketing',
    description: 'Led a social media campaign that generated over 1 million impressions and 5,000 leads.',
    image: 'Screenshots of a successful social media campaign.',
  },
  {
    title: 'Client Gamma',
    category: 'Business Development',
    description: 'Secured three major enterprise clients, expanding market share by 15%.',
    image: 'Logos of well-known enterprise companies.',
  },
];

const PortfolioPage = () => {
  const { toast } = useToast();

  const handleViewClick = () => {
    toast({
      title: "🚧 Feature Coming Soon",
      description: "Detailed case studies will be available shortly!",
    });
  };

  return (
    <>
      <Helmet>
        <title>Portfolio - Farid Khan</title>
        <meta name="description" content="View past work, successful campaigns, and client success stories from Farid Khan." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">My Portfolio</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              A selection of projects that showcase my expertise and the results I've delivered.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioItems.map((item, index) => (
              <motion.div
                key={item.title}
                className="card overflow-hidden"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <img  className="w-full h-56 object-cover" alt={item.title} src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                <div className="p-6">
                  <p className="text-sm font-semibold text-royal-blue mb-1">{item.category}</p>
                  <h3 className="text-2xl font-bold text-charcoal-black mb-2">{item.title}</h3>
                  <p className="text-gray-600 mb-4">{item.description}</p>
                  <button onClick={handleViewClick} className="font-bold text-royal-blue hover:underline flex items-center gap-2">
                    View Case Study <ExternalLink size={16} />
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};

export default PortfolioPage;