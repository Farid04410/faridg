import React from "react";
const LoginPage = () => {
  return null;
};
export default LoginPage;