import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowRight, TrendingUp, Lightbulb, Users } from 'lucide-react';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>Farid Khan | Sales & Marketing Expert</title>
        <meta name="description" content="Farid Khan - Expert in Sales, Marketing & Business Development. Helping you grow your business with proven strategies." />
        <meta name="keywords" content="Farid Khan, Sales Expert, Marketing Consultant, Business Development, India" />
      </Helmet>
      
      <section className="bg-charcoal text-white text-center section">
        <div className="container mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4">
              Helping You Grow Your Business
            </h1>
            <p className="max-w-2xl mx-auto text-lg md:text-xl text-gray-300 mb-8">
              Expert in Sales, Marketing & Business Development
            </p>
            <div className="flex justify-center gap-4">
              <Link to="/book-a-call">
                <Button size="lg" className="btn-primary">
                  Book a Call <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/services">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-charcoal-black">
                  My Services
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section bg-light-gray">
        <div className="container mx-auto">
          <h2 className="section-title">What I Offer</h2>
          <div
            className="grid grid-cols-1 md:grid-cols-3 gap-8"
          >
            {[
              { icon: TrendingUp, title: 'Sales Strategy', desc: 'Crafting bespoke sales strategies that deliver measurable results and drive revenue growth.' },
              { icon: Lightbulb, title: 'Business Consulting', desc: 'Providing expert guidance to optimize operations and uncover new opportunities.' },
              { icon: Users, title: 'Digital Marketing', desc: 'Leveraging digital channels to build your brand and connect with your target audience.' },
            ].map((feature, i) => (
              <motion.div
                key={i}
                className="card text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <div className="flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6 mx-auto">
                  <feature.icon className="w-8 h-8 text-royal-blue" />
                </div>
                <h3 className="text-xl font-bold text-charcoal-black mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      
      <section className="bg-white section">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-charcoal-black mb-4">Let’s build your future – together.</h2>
          <p className="text-gray-600 mb-8">Ready to take the next step? Let's discuss how I can help you achieve your goals.</p>
          <Link to="/contact">
            <Button size="lg" className="btn-primary">
              Get In Touch
            </Button>
          </Link>
        </div>
      </section>
    </>
  );
};

export default HomePage;