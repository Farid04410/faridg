import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { User, Mail, MessageSquare, Phone, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ContactPage = () => {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Message Sent!",
        description: "Thank you for reaching out. I'll get back to you soon.",
      });
      setFormData({ name: '', email: '', message: '' });
    }, 1500);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <Helmet>
        <title>Contact - Farid Khan</title>
        <meta name="description" content="Contact Farid Khan for business inquiries, consultations, or any other questions." />
      </Helmet>
      <section className="section">
        <div className="container mx-auto">
          <motion.div
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="section-title">Contact Me</h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
              Have a project in mind or just want to say hello? I'd love to hear from you.
            </p>
          </motion.div>

          <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-16 items-start">
            <motion.div
              className="card"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="text" name="name" value={formData.name} onChange={handleInputChange} placeholder="Your Name" className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-royal-blue" required />
                </div>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input type="email" name="email" value={formData.email} onChange={handleInputChange} placeholder="Your Email" className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-royal-blue" required />
                </div>
                <div className="relative">
                  <MessageSquare className="absolute left-3 top-5 w-5 h-5 text-gray-400" />
                  <textarea name="message" value={formData.message} onChange={handleInputChange} placeholder="Your Message" rows="5" className="w-full pl-10 pr-4 py-3 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-royal-blue" required></textarea>
                </div>
                <Button type="submit" disabled={isLoading} className="w-full btn-primary">
                  {isLoading ? 'Sending...' : 'Send Message'}
                </Button>
              </form>
            </motion.div>
            <motion.div
              className="space-y-8"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                      <Mail className="w-6 h-6 text-royal-blue" />
                  </div>
                  <div>
                      <h3 className="text-xl font-bold">Email</h3>
                      <a href="mailto:contact@faridkhan.com" className="text-gray-600 hover:text-royal-blue">contact@faridkhan.com</a>
                  </div>
              </div>
              <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                      <Phone className="w-6 h-6 text-royal-blue" />
                  </div>
                  <div>
                      <h3 className="text-xl font-bold">Phone / WhatsApp</h3>
                      <a href="https://wa.me/917077572478" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-royal-blue">+91 70775 72478</a>
                  </div>
              </div>
              <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex-shrink-0 flex items-center justify-center rounded-full bg-blue-100">
                      <MapPin className="w-6 h-6 text-royal-blue" />
                  </div>
                  <div>
                      <h3 className="text-xl font-bold">Location</h3>
                      <p className="text-gray-600">Based in India, serving clients globally.</p>
                  </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;